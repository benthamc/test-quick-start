###
# Created: 03/21/2020
#
# Author: mbhandek
#
# Description: Created for preprod2 deployment
###

###########################################################################
### OCI Provider authentication configurations                          ###
### More details:https://www.terraform.io/docs/providers/oci/index.html ###
###########################################################################

# Your tenancy's OCID
export TF_VAR_tenancy_ocid="ocid1.tenancy.oc1..aaaaaaaafoos7w2vdh2ioaxenmwja76vymxe2pcjt72ahe5fm336ugtnueka"

# The user's OCID that will run the terrafor -- Not required for OCI Resource Managerm
#export TF_VAR_user_ocid="YOUR_INPUT_HERE"

# Finger print of the user's auth key -- Not required for OCI Resource Manager"
#export TF_VAR_fingerprint="YOUR_INPUT_HERE"

# Path to the user's auth key -- Not required for OCI Resource Manager"
#export TF_VAR_private_key_path="YOUR_INPUT_HERE"

# OCI region to run the terraform, for example us-phoenix-1."
export TF_VAR_region="us-ashburn-1"


##############################################
### Overlay Bastion 3.0 related configurations
##############################################

#CompartmentId where all VCN resources lies in"
export TF_VAR_compartment_id="ocid1.compartment.oc1..aaaaaaaaj2jaido4gbfkjzcqxzd5w3cipcojledgiotmx7omkiodiufwm5da"

# The OB3 requestor tenancy id. You can find it in https://confluence.oci.oraclecorp.com/display/OS/Overlay+Bastion+3.0+Tenancy+Information#OverlayBastion3.0TenancyInformation-TenancyInformation
export TF_VAR_ob3_requestor_tenancy_id="ocid1.tenancy.oc1..aaaaaaaa53y25ignaxvfgpj47yjj44wl75vce2dxhgwjq3tg6ncj7ojv2qoa"

# The OB3 requestor group id. You can find it in https://confluence.oci.oraclecorp.com/display/OS/Overlay+Bastion+3.0+Tenancy+Information#OverlayBastion3.0TenancyInformation-TenancyInformation
export TF_VAR_ob3_requestor_group_id="ocid1.group.oc1..aaaaaaaafmh6xfprwmfpffk3a4y4bhi5hyp42ugqrgxffcc6ae5tyiajvkaa"

