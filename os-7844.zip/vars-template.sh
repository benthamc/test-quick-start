###########################################################################
### OCI Provider authentication configurations                          ###
### More details:https://www.terraform.io/docs/providers/oci/index.html ###
###########################################################################

# Your tenancy's OCID
export TF_VAR_tenancy_ocid="YOUR_INPUT_HERE"

# The user's OCID that will run the terrafor -- Not required for OCI Resource Managerm
#export TF_VAR_user_ocid="YOUR_INPUT_HERE"

# Finger print of the user's auth key -- Not required for OCI Resource Manager"
#export TF_VAR_fingerprint="YOUR_INPUT_HERE"

# Path to the user's auth key -- Not required for OCI Resource Manager"
#export TF_VAR_private_key_path="YOUR_INPUT_HERE"

# OCI region to run the terraform, for example us-phoenix-1."
export TF_VAR_region="YOUR_INPUT_HERE"


##############################################
### Overlay Bastion 3.0 related configurations
##############################################

#CompartmentId where all VCN resources lies in"
export TF_VAR_compartment_id="YOUR_INPUT_HERE"

# The OB3 requestor tenancy id. You can find it in https://confluence.oci.oraclecorp.com/display/OS/Overlay+Bastion+3.0+Tenancy+Information#OverlayBastion3.0TenancyInformation-TenancyInformation
export TF_VAR_ob3_requestor_tenancy_id="YOUR_INPUT_HERE"

# The OB3 requestor group id. You can find it in https://confluence.oci.oraclecorp.com/display/OS/Overlay+Bastion+3.0+Tenancy+Information#OverlayBastion3.0TenancyInformation-TenancyInformation
export TF_VAR_ob3_requestor_group_id="YOUR_INPUT_HERE"
